import bpy
import os

bl_info = {
	"name": "Komikaze",
	"category": "Komikaze",
	"author": "Double Gum",
	"blender": (2,80,0),
	"location": "Node Editor Toolbar",
	"description": "Toon Shader Pack",
	"warning": "",
	"wiki_url":"https://blendermarket.com/products/komikaze",
	"tracker_url": "https://blendermarket.com/creators/doublegum",
	"version":('1', '3')
}
class ADD_OT_komikaze(bpy.types.Operator):
	bl_idname = 'add.komikaze'
	bl_description = 'Add Node Setup'
	bl_category = 'Node'
	bl_label = 'Add Setup'

	choice: bpy.props.StringProperty()

	def execute(self, context):
		propstr = 'type,inputs,outputs,internal_links,parent,use_custom_color,select,show_options,show_preview,mute,show_texture,group,shading_compatibility,is_active_output'
		if self.choice in ['Alpha', 'Aqua', 'ASCII', 'Blueprint', 'Chroma', 'Cosmos', 'Dither', 'Ember', 'Heavy Metal', 'Hologram', 'Hope', 'Inferno', 'Jaipur Noire', 'Kismet', 'Kismet Star', 'Molly', 'Notepad+', 'Outlines', 'Polka Dots', 'Prism', 'Rocky', 'Scribbles', 'Shaderverse', 'Shaderverse 3 Tones', 'Snow', 'UI', 'Wind Waker']:
			context.scene.Komikaze_mat_enum = self.choice
		mat_ref = {'Alpha': ('Alphaexp', ['Alpha']), 'Aqua': ('Aquaexp', ['Aqua']), 'ASCII': ('ASCIIexp', ['ASCII']), 'Blueprint': ('Blueprintexp', ['Blueprint']), 'Chroma': ('Chromaexp', ['Chroma']), 'Cosmos': ('Cosmosexp', ['Cosmos']), 'Dither': ('Ditherexp', ['Dither']), 'Ember': ('Ember 2exp', ['Ember']), 'Heavy Metal': ('Heavy Metalexp', ['Reroute', 'Normal.001', 'Normal', 'Reroute.001', 'Reroute.002', 'Geometry', 'Heavy Metal']), 'Hologram': ('Hologramexp', ['Hologram']), 'Hope': ('Hopeexp', ['Hope.001']), 'Inferno': ('Infernoexp', ['Group', 'Inferno']), 'Jaipur Noire': ('Jaipur Noireexp', ['Normal', 'Jaipur Noire.001', 'Jaipur Noire']), 'Kismet': ('Kismetexp', ['Kismet']), 'Kismet Star': ('Starexp', ['Kismet Star']), 'Molly': ('Mollyexp', ['Hope', 'Geometry', 'Transparent BSDF', 'Molly', 'Mix Shader']), 'Notepad+': ('Notepad+exp', ['Notepad+']), 'Outlines': ('Outlinesexp', ['Geometry.001', 'Emission.002', 'Transparent BSDF.002', 'Mix Shader.002']), 'Polka Dots': ('Polka Dotsexp', ['Polka Dots']), 'Prism': ('Prismexp', ['Prism', 'Group']), 'Rocky': ('Rockyexp', ['Rocky']), 'Scribbles': ('Scribblesexp', ['Scribbles']), 'Shaderverse': ('Shaderverseexp', ['Shaderverse']), 'Shaderverse 3 Tones': ('Shaderverse 3 Tonesexp', ['Shaderverse 3 Tones']), 'Snow': ('Snowexp', ['Snow']), 'UI': ('UI Blackexp', ['UI']), 'Wind Waker': ('Wind Wakerexp', ['UV Mapping :', 'Wind Waker'])}
		select_mat_name = context.scene.Komikaze_mat_enum
		select_mat = mat_ref[select_mat_name][0]
		file_loc= os.path.join(os.path.dirname(__file__), "data", "data.blend")
		if context.space_data.tree_type == "ShaderNodeTree" and context.space_data.shader_type == "OBJECT":
			with bpy.data.libraries.load(file_loc) as (data_from, data_to):
				data_to.materials = [data_from.materials[data_from.materials.index(select_mat)]]
			target_tree = bpy.data.materials[select_mat]
			current_tree = context.object.active_material.node_tree
			target_nodes = [mn for mn in target_tree.node_tree.nodes if mn.name in mat_ref[select_mat_name][1]]
			current_nodes = current_tree.nodes
			current_group_nodes = [gn for gn in current_nodes if gn.type == "GROUP"]
			mat_props = self.get_mirror_props(propstr + ",name", target_tree)
			for mp in mat_props:
				setattr(context.object.active_material, mp, getattr(target_tree, mp))
			mat_props_cycles = self.get_mirror_props(propstr, target_tree.cycles)
			for mpc in mat_props_cycles:
				setattr(context.object.active_material.cycles, mpc, getattr(target_tree.cycles, mpc))
			node_dict = {}
			for t in target_nodes:
				new_n = current_nodes.new(type=t.bl_idname)
				props = self.get_mirror_props(propstr, t)
				if t.type=="IMAGE":
					props.remove("layer")
					props.remove("view")
				for p in props:
					setattr(new_n, p, getattr(t, p))
				if t.type != "REROUTE":
					for ti in range(len(t.inputs)):
						if "default_value" in dir(t.inputs[ti]):
							new_n.inputs[ti].default_value = t.inputs[ti].default_value
						if "min_value" in dir(t.inputs[ti]) and "max_value" in dir(t.inputs[ti]):
							new_n.inputs[ti].min_value = t.inputs[ti].min_value
							new_n.inputs[ti].max_value = t.inputs[ti].max_value
					for to in range(len(t.outputs)):
						if "default_value" in dir(t.outputs[to]):
							new_n.outputs[to].default_value = t.outputs[to].default_value
						if "min_value" in dir(t.outputs[to]) and "max_value" in dir(t.outputs[to]):
							new_n.outputs[to].min_value = t.outputs[to].min_value
							new_n.outputs[to].max_value = t.outputs[to].max_value
				node_dict[t.name] = new_n

				if t.type == "GROUP":
					collect = sorted([n for n in current_group_nodes if t.label == n.name])
					if collect:
						new_n.node_tree = collect[0].node_tree
					new_n.name = new_n.label
					new_n.label = ""
				elif t.type == "VALTORGB":
					ramp_props = self.get_mirror_props(propstr, t.color_ramp)
					for rp in ramp_props:
						setattr(new_n.color_ramp, rp, getattr(t.color_ramp, rp))
					telems = t.color_ramp.elements
					nelems = new_n.color_ramp.elements
					for _ in range(len(telems) - 2):
						nelems.new(0.5)
					for elem in range(len(nelems)):
						nelems[elem].alpha = telems[elem].alpha
						nelems[elem].color = telems[elem].color
						nelems[elem].position = telems[elem].position
			for l in target_tree.node_tree.links:
				frm_n = l.from_node
				to_n = l.to_node
				if frm_n in target_nodes and to_n in target_nodes:
					frm_sock_idx = list(frm_n.outputs).index(l.from_socket)
					to_sock_idx = list(to_n.inputs).index(l.to_socket)
					current_tree.links.new(node_dict[frm_n.name].outputs[frm_sock_idx], node_dict[to_n.name].inputs[to_sock_idx])
			bpy.data.materials.remove(target_tree)
		for grp in bpy.data.node_groups:
			if not grp.users:
				bpy.data.node_groups.remove(grp)
		return {"FINISHED"}

	def get_mirror_props(self, propstr, n):
		return [i for i in dir(n) if self.check_prop(propstr.split(","), i) and not i.startswith("__") and not callable(getattr(n, i)) and not n.is_property_readonly(i)]
	def check_prop(self, props, toCheck):
		if toCheck in props or toCheck.startswith("bl_"):
			return False
		return True



class KOMIKAZE_PT_panel(bpy.types.Panel):
	bl_space_type = 'NODE_EDITOR'
	bl_region_type = 'UI'
	bl_category = 'Komikaze'
	bl_label = 'Komikaze'

	@classmethod
	def poll(cls, context):
		if (context.space_data.tree_type == "ShaderNodeTree" and context.space_data.shader_type == "OBJECT"):
			return True
		else:
			return False

	def draw(self, context):
		layout = self.layout
		row = layout.row()
		if context.scene.render.engine not in ["CYCLES", "BLENDER_EEVEE"]:
			row.label(text="Only Cycles / Eevee supported")
		else:
			if context.space_data.tree_type == "ShaderNodeTree" and context.space_data.shader_type == "OBJECT":
				if not context.object:
					row.label(text="Select Object")
				elif not context.object.active_material:
					row.label(text="Add Material")
				elif not context.object.active_material.node_tree:
					row.label(text="Enable Nodes")
				else:
					row.prop(context.scene, 'Komikaze_mat_enum')
					row = layout.row()
					row.scale_y=1.5
					row.operator(ADD_OT_komikaze.bl_idname, text="Add Shader")




class ADD_MT_komikaze(bpy.types.Menu):
	bl_idname = 'NODE_MT_add_komikaze'
	bl_label = 'Komikaze'

	def draw(self, context):
		layout = self.layout
		if context.space_data.tree_type == "ShaderNodeTree" and context.space_data.shader_type == "OBJECT":
			layout.operator(ADD_OT_komikaze.bl_idname, text="Alpha").choice = "Alpha"
			layout.operator(ADD_OT_komikaze.bl_idname, text="Aqua").choice = "Aqua"
			layout.operator(ADD_OT_komikaze.bl_idname, text="ASCII").choice = "ASCII"
			layout.operator(ADD_OT_komikaze.bl_idname, text="Blueprint").choice = "Blueprint"
			layout.operator(ADD_OT_komikaze.bl_idname, text="Chroma").choice = "Chroma"
			layout.operator(ADD_OT_komikaze.bl_idname, text="Cosmos").choice = "Cosmos"
			layout.operator(ADD_OT_komikaze.bl_idname, text="Dither").choice = "Dither"
			layout.operator(ADD_OT_komikaze.bl_idname, text="Ember").choice = "Ember"
			layout.operator(ADD_OT_komikaze.bl_idname, text="Heavy Metal").choice = "Heavy Metal"
			layout.operator(ADD_OT_komikaze.bl_idname, text="Hologram").choice = "Hologram"
			layout.operator(ADD_OT_komikaze.bl_idname, text="Hope").choice = "Hope"
			layout.operator(ADD_OT_komikaze.bl_idname, text="Inferno").choice = "Inferno"
			layout.operator(ADD_OT_komikaze.bl_idname, text="Jaipur Noire").choice = "Jaipur Noire"
			layout.operator(ADD_OT_komikaze.bl_idname, text="Kismet").choice = "Kismet"
			layout.operator(ADD_OT_komikaze.bl_idname, text="Kismet Star").choice = "Kismet Star"
			layout.operator(ADD_OT_komikaze.bl_idname, text="Molly").choice = "Molly"
			layout.operator(ADD_OT_komikaze.bl_idname, text="Notepad+").choice = "Notepad+"
			layout.operator(ADD_OT_komikaze.bl_idname, text="Outlines").choice = "Outlines"
			layout.operator(ADD_OT_komikaze.bl_idname, text="Polka Dots").choice = "Polka Dots"
			layout.operator(ADD_OT_komikaze.bl_idname, text="Prism").choice = "Prism"
			layout.operator(ADD_OT_komikaze.bl_idname, text="Rocky").choice = "Rocky"
			layout.operator(ADD_OT_komikaze.bl_idname, text="Scribbles").choice = "Scribbles"
			layout.operator(ADD_OT_komikaze.bl_idname, text="Shaderverse").choice = "Shaderverse"
			layout.operator(ADD_OT_komikaze.bl_idname, text="Shaderverse 3 Tones").choice = "Shaderverse 3 Tones"
			layout.operator(ADD_OT_komikaze.bl_idname, text="Snow").choice = "Snow"
			layout.operator(ADD_OT_komikaze.bl_idname, text="UI").choice = "UI"
			layout.operator(ADD_OT_komikaze.bl_idname, text="Wind Waker").choice = "Wind Waker"


def komikaze_menu(self, context):
	mats=27
	worlds=0
	comps=0
	if context.space_data.tree_type == "ShaderNodeTree" and context.space_data.shader_type == "OBJECT" and mats:
		self.layout.menu(ADD_MT_komikaze.bl_idname)
	if context.space_data.tree_type == "ShaderNodeTree" and context.space_data.shader_type == "WORLD" and worlds:
		self.layout.menu(ADD_MT_komikaze.bl_idname)
	if context.space_data.tree_type == "CompositorNodeTree" and comps:
		self.layout.menu(ADD_MT_komikaze.bl_idname)

classes=(ADD_OT_komikaze,KOMIKAZE_PT_panel,ADD_MT_komikaze)
def register():
	from bpy.utils import register_class
	for cls in classes:
		register_class(cls)
	bpy.types.NODE_MT_add.append(komikaze_menu)
	bpy.types.Scene.Komikaze_mat_enum = bpy.props.EnumProperty(items = [("Alpha","Alpha","Alpha"),("Aqua","Aqua","Aqua"),("ASCII","ASCII","ASCII"),("Blueprint","Blueprint","Blueprint"),("Chroma","Chroma","Chroma"),("Cosmos","Cosmos","Cosmos"),("Dither","Dither","Dither"),("Ember","Ember","Ember"),("Heavy Metal","Heavy Metal","Heavy Metal"),("Hologram","Hologram","Hologram"),("Hope","Hope","Hope"),("Inferno","Inferno","Inferno"),("Jaipur Noire","Jaipur Noire","Jaipur Noire"),("Kismet","Kismet","Kismet"),("Kismet Star","Kismet Star","Kismet Star"),("Molly","Molly","Molly"),("Notepad+","Notepad+","Notepad+"),("Outlines","Outlines","Outlines"),("Polka Dots","Polka Dots","Polka Dots"),("Prism","Prism","Prism"),("Rocky","Rocky","Rocky"),("Scribbles","Scribbles","Scribbles"),("Shaderverse","Shaderverse","Shaderverse"),("Shaderverse 3 Tones","Shaderverse 3 Tones","Shaderverse 3 Tones"),("Snow","Snow","Snow"),("UI","UI","UI"),("Wind Waker","Wind Waker","Wind Waker")], default="Wind Waker", name="Shader")

def unregister():
	from bpy.utils import unregister_class
	for cls in classes:
		unregister_class(cls)
	del bpy.types.Scene.Komikaze_mat_enum

	bpy.types.NODE_MT_add.remove(komikaze_menu)
